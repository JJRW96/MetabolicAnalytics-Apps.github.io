    // Get the last values
    const lastIndex = simulationResults.time.length - 1;
    const lastTime = simulationResults.time[lastIndex];
    const lastPower = simulationResults.power[lastIndex];
    const lastVO2 = simulationResults.vo2[lastIndex];
    const lastMuscleLactate = simulationResults.muscleLactate[lastIndex];
    const lastBloodLactate = simulationResults.bloodLactate[lastIndex];
    const lastPH = simulationResults.pH[lastIndex];
    const lastPCr = simulationResults.pcr[lastIndex];
    const lastATP = simulationResults.atp[lastIndex];
    const lastADP = simulationResults.adp[lastIndex];
    
    // Current power
    const currentPower = simulationState.currentPower;
    
    // Calculate ATP consumption rate based on power
    const atpConsumptionRate = B_POW * currentPower;
    
    // Calculate VO2 (simplified model with exponential rise)
    const vo2ss = Math.min(modelParameters.vo2max, 300 + (B_VO2 * atpConsumptionRate * 1000)); // Steady state VO2
    const tVO2 = 30; // Time constant for VO2 kinetics (seconds)
    const deltaVO2 = (vo2ss - lastVO2) * (1 - Math.exp(-1/tVO2));
    const currentVO2 = lastVO2 + deltaVO2;
    
    // Calculate oxidative phosphorylation rate
    const oxidativePhosphorylationRate = currentVO2 / (B_VO2 * 1000); // Convert from ml/min to mmol/s/kg
    
    // Calculate glycolysis rate (VLamax)
    const currentVLAmax = modelParameters.vlamax;
    
    // Calculate pH effect on glycolysis
    const pHEffect = Math.max(0, 1 - Math.pow((7.4 - lastPH) / 0.6, 2));
    
    // Calculate actual glycolysis rate
    const glycolysisActivation = Math.min(1, Math.pow(lastADP, 2) / (Math.pow(0.01, 2) + Math.pow(lastADP, 2)));
    const actualGlycolysisRate = currentVLAmax * glycolysisActivation * pHEffect;
    
    // Calculate lactate production and oxidation
    const lactateProdRate = actualGlycolysisRate;
    const lactateOxidationRate = Math.min(lactateProdRate, 0.1 * (lastMuscleLactate / (5 + lastMuscleLactate)));
    const netLactateProductionRate = lactateProdRate - lactateOxidationRate;
    
    // Calculate muscle lactate accumulation
    const deltaMuscleLactate = netLactateProductionRate - 0.05 * (lastMuscleLactate - lastBloodLactate);
    const currentMuscleLactate = Math.max(0, lastMuscleLactate + deltaMuscleLactate);
    
    // Calculate blood lactate accumulation
    const deltaBloodLactate = 0.02 * (lastMuscleLactate - lastBloodLactate) - 0.01 * lastBloodLactate;
    const currentBloodLactate = Math.max(0, lastBloodLactate + deltaBloodLactate);
    
    // Calculate pH
    const deltaPH = -0.005 * deltaMuscleLactate / DBUFF;
    const currentPH = Math.max(6.8, Math.min(7.4, lastPH + deltaPH));
    
    // Calculate PCr and ATP
    const totalPhosphorylationRate = oxidativePhosphorylationRate + actualGlycolysisRate;
    const phosphorylationDeficit = atpConsumptionRate - totalPhosphorylationRate;
    
    // PCr decreases to compensate for ATP deficit
    const deltaPCr = -phosphorylationDeficit;
    const currentPCr = Math.max(5, Math.min(initialValues.pcr, lastPCr + deltaPCr));