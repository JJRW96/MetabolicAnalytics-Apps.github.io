# Mader Modell - Extrahierte Gleichungen und Parameter

## Konstanten und Standardwerte
- STEP_DURATION_SECONDS = 30
- STARTING_POWER_WATTS = 60
- POWER_INCREMENT_WATTS = 20
- MAX_POWER_WATTS = 500
- DEFAULT_VO2MAX_ML_MIN = 6000
- DEFAULT_VLAMAX = 0.70
- M2 = 1.66e9 (CK-Gleichgewichtskonstante, mol^-1)
- M3 = 0.95 (Adenylat-Kinase-Gleichgewichtskonstante)
- DG0 = -30.6 (Standardfreie Energie des [ATP]/[PCr]-Systems, kJ/mol)
- R = 8.314 / 1000 (Gaskonstante, kJ/mol/K)
- T = 310 (Temperatur in Kelvin, 37°C)
- DBUFF = 25 (Pufferkapazität der Skelettmuskulatur, mmol/l/pH-Einheit)
- B_VO2 = 4.3 (Transformationskoeffizient von VO2 in vGP, ml O2/mmol GP)
- B_V_LA = 1.4 (Transformationskoeffizient von vla in vGP,vla, mmol Laktat/mmol GP)
- B_POW = 0.00267 (Rate des GP-Verbrauchs pro Watt, mmol/kg/s/Watt)

## Anfangswerte für metabolische Parameter
- ATP = 7.0 mmol/kg
- PCr = 25.0 mmol/kg
- Pi = 3.0 mmol/kg
- pH = 7.4
- Muskellaktat = 1.0 mmol/l
- Blutlaktat = 1.0 mmol/l
- VO2 = 300 ml/min (Ruhe)

## Schlüsselgleichungen

### ATP-Verbrauchsrate
- atpConsumptionRate = B_POW * currentPower

### Sauerstoffaufnahme (VO2)
- vo2ss = Math.min(modelParameters.vo2max, 300 + (B_VO2 * atpConsumptionRate * 1000))
- tVO2 = 30 (Zeitkonstante für VO2-Kinetik in Sekunden)
- deltaVO2 = (vo2ss - lastVO2) * (1 - Math.exp(-1/tVO2))
- currentVO2 = lastVO2 + deltaVO2

### Oxidative Phosphorylierung
- oxidativePhosphorylationRate = currentVO2 / (B_VO2 * 1000)

### Glykolyse und pH-Effekt
- pHEffect = Math.max(0, 1 - Math.pow((7.4 - lastPH) / 0.6, 2))
- glycolysisActivation = Math.min(1, Math.pow(lastADP, 2) / (Math.pow(0.01, 2) + Math.pow(lastADP, 2)))
- actualGlycolysisRate = currentVLAmax * glycolysisActivation * pHEffect

### Laktatproduktion und -oxidation
- lactateProdRate = actualGlycolysisRate
- lactateOxidationRate = Math.min(lactateProdRate, 0.1 * (lastMuscleLactate / (5 + lastMuscleLactate)))
- netLactateProductionRate = lactateProdRate - lactateOxidationRate

### Muskellaktatakkumulation
- deltaMuscleLactate = netLactateProductionRate - 0.05 * (lastMuscleLactate - lastBloodLactate)
- currentMuscleLactate = Math.max(0, lastMuscleLactate + deltaMuscleLactate)

### Blutlaktatakkumulation
- deltaBloodLactate = 0.02 * (lastMuscleLactate - lastBloodLactate) - 0.01 * lastBloodLactate
- currentBloodLactate = Math.max(0, lastBloodLactate + deltaBloodLactate)

### pH-Berechnung
- deltaPH = -0.005 * deltaMuscleLactate / DBUFF
- currentPH = Math.max(6.8, Math.min(7.4, lastPH + deltaPH))

### PCr und ATP
- totalPhosphorylationRate = oxidativePhosphorylationRate + actualGlycolysisRate
- phosphorylationDeficit = atpConsumptionRate - totalPhosphorylationRate
- deltaPCr = -phosphorylationDeficit
- currentPCr = Math.max(5, Math.min(initialValues.pcr, lastPCr + deltaPCr))
- deltaATP = 0 (ATP wird konstant gehalten)
- currentATP = lastATP
- currentADP = Math.sqrt((lastATP * initialValues.pi) / (M2 * Math.pow(10, -lastPH) * lastPCr))

## Zu simulierende metabolische Parameter
1. VO2ss (Steady-State-Sauerstoffaufnahme)
2. VLamax (Maximale Rate der Laktatbildung)
3. VLaox (Rate der Laktatelimination durch Oxidation)
4. Pyruvatdefizit
5. Muskellaktatakkumulation
6. Blutlaktatakkumulation
7. pH
8. PCr-Werte
9. ATP-Werte

## Stufentest-Protokoll (Benutzeranforderungen)
- 30-Sekunden-Stufen
- Startleistung: 60 Watt
- Inkrement: 20 Watt pro Stufe
- Maximale Leistung: 500 Watt
- Standard-VO2max: 6000 ml/min
- Standard-VLamax: 0,70
